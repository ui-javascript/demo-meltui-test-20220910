
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as a,d as s,u as e,A as o,c as t,j as l,l as n,h as r,n as d,s as i,t as u,e as c,k as p,J as b}from"./index.eae74150.js";const f=["src"],g={key:1},h=s({name:"Logo"});var v=a(Object.assign(h,{props:{showLogo:{type:Boolean,default:!0},showTitle:{type:Boolean,default:!0}},setup(a){const s=e(),h=o("admin后台"),v=o("./assets/logo.eb12b828.png"),m=t((()=>{let a={};return s.dashboard.enable&&(a.name="dashboard"),a}));return(e,o)=>{const t=i("router-link");return u(),l(t,{to:r(m),class:d(["title",{"is-link":r(s).dashboard.enable}]),title:h.value},{default:n((()=>[a.showLogo?(u(),c("img",{key:0,src:v.value,class:"logo"},null,8,f)):p("v-if",!0),a.showTitle?(u(),c("span",g,b(h.value),1)):p("v-if",!0)])),_:1},8,["to","class","title"])}}}),[["__scopeId","data-v-fc6b657e"]]);export{v as default};
//# sourceMappingURL=index.5dcd6b55.js.map
