
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as a,A as n,bf as s,o as e,e as t,g as o,f as c,l,bg as r,M as i,N as d,q as u,t as f,Y as v,J as p}from"./index.77a2b8a5.js";import{E as m}from"./el-button.5a3907a7.js";import{_}from"./index.dcd4b65f.js";import"./index.8bfffa1c.js";import"./index2.240ee0c6.js";import"./index2.1dc5c761.js";const b=a=>(i("data-v-439c912c"),a=a(),d(),a),j={class:"notfound"},x={class:"content"},w=b((()=>c("h1",null,"404",-1))),I=b((()=>c("div",{class:"desc"},"抱歉，你访问的页面不存在",-1))),y={__name:"[...all]",setup(a){const r=u(),i=n({inter:null,countdown:5});function d(){r.push("/")}return s((()=>{clearInterval(i.value.inter)})),e((()=>{i.value.inter=setInterval((()=>{i.value.countdown--,0==i.value.countdown&&(clearInterval(i.value.inter),d())}),1e3)})),(a,n)=>{const s=_,e=m;return f(),t("div",j,[o(s,{name:"404",class:"icon"}),c("div",x,[w,I,o(e,{type:"primary",onClick:d},{default:l((()=>[v(p(i.value.countdown)+" 秒后，返回首页",1)])),_:1})])])}}};"function"==typeof r&&r(y);var g=a(y,[["__scopeId","data-v-439c912c"]]);export{g as default};
//# sourceMappingURL=_...all_.4367928c.js.map
