
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as a,_ as e,u as t,t as s,e as o,h as r,J as i,k as p,L as n,M as c,N as y,f as h}from"./index.eae74150.js";const g=a=>(c("data-v-78cda0a3"),a=a(),y(),a),d={class:"copyright"},f=g((()=>h("span",null,"Copyright",-1))),b=g((()=>h("span",{class:"icon"},"©",-1))),k={key:0},l=["href"],m={key:1},v={key:2,href:"https://beian.miit.gov.cn/",target:"_blank",rel:"noopener"},_=a({name:"Copyright"});var u=e(Object.assign(_,{setup(a){const e=t();return(a,t)=>(s(),o("footer",d,[f,b,r(e).copyright.dates?(s(),o("span",k,i(r(e).copyright.dates),1)):p("v-if",!0),r(e).copyright.company?(s(),o(n,{key:1},[r(e).copyright.website?(s(),o("a",{key:0,href:r(e).copyright.website,target:"_blank",rel:"noopener"},i(r(e).copyright.company),9,l)):(s(),o("span",m,i(r(e).copyright.company),1))],64)):p("v-if",!0),r(e).copyright.beian?(s(),o("a",v,i(r(e).copyright.beian),1)):p("v-if",!0)]))}}),[["__scopeId","data-v-78cda0a3"]]);export{u as _};
//# sourceMappingURL=index.449829e7.js.map
