
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as e,d as a,u as s,b as i,H as n,j as t,l as d,T as r,O as o,t as m,h as l,e as c,f,g as p,k as b,L as u,P as j,n as v,J as x}from"./index.1d015b2d.js";/* empty css                */import{_ as h}from"./index.6eeb5b7f.js";import k from"./index.78a1fc2a.js";import _ from"./index.a7321057.js";import"./el-button.9b8b83db.js";import"./index.8bfffa1c.js";import"./index2.538a4d30.js";import"./index2.35bfb458.js";/* empty css                  */import"./index2.fc726b33.js";import"./error2.13f96d52.js";import"./index2.157a72b2.js";const y={key:0},g={class:"header-container"},M={class:"main"},C={class:"nav"},H=["onClick"],O={key:0},w=a({name:"Header"});var I=e(Object.assign(w,{setup(e){const a=s(),w=i(),I=o("switchMenu");return(e,s)=>{const i=h,o=n;return m(),t(r,{name:"header"},{default:d((()=>["pc"===l(a).mode&&"head"===l(a).menu.menuMode?(m(),c("header",y,[f("div",g,[f("div",M,[p(k),b(" 顶部模式 "),f("div",C,[(m(!0),c(u,null,j(l(w).allMenus,((e,a)=>(m(),c(u,null,[e.children&&0!==e.children.length?(m(),c("div",{key:a,class:v(["item",{active:a==l(w).actived}]),onClick:e=>l(I)(a)},[p(o,null,{default:d((()=>[e.meta.icon?(m(),t(i,{key:0,name:e.meta.icon},null,8,["name"])):b("v-if",!0)])),_:2},1024),e.meta.title?(m(),c("span",O,x(e.meta.title),1)):b("v-if",!0)],10,H)):b("v-if",!0)],64)))),256))])]),p(_)])])):b("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-339849a1"]]);export{I as default};
//# sourceMappingURL=index.48a15d24.js.map
