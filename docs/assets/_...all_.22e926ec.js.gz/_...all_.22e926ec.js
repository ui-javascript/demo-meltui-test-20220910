
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as a,A as n,bB as s,o as t,e,g as o,f as l,l as r,bh as c,M as d,N as i,q as u,t as f,Y as v,J as p}from"./index.c66562dd.js";import{E as m}from"./el-button.6180889b.js";import{_}from"./index.46d30d13.js";import"./index.8bfffa1c.js";import"./index2.1c3d2afc.js";import"./index2.c2e41879.js";const j=a=>(d("data-v-403579f9"),a=a(),i(),a),x={class:"notfound"},b={class:"content"},w=j((()=>l("h1",null,"404",-1))),I=j((()=>l("div",{class:"desc"},"抱歉，你访问的页面不存在",-1))),h={__name:"[...all]",setup(a){const c=u(),d=n({inter:null,countdown:5});function i(){c.push("/")}return s((()=>{clearInterval(d.value.inter)})),t((()=>{d.value.inter=setInterval((()=>{d.value.countdown--,0==d.value.countdown&&(clearInterval(d.value.inter),i())}),1e3)})),(a,n)=>{const s=_,t=m;return f(),e("div",x,[o(s,{name:"404",class:"icon"}),l("div",b,[w,I,o(t,{type:"primary",onClick:i},{default:r((()=>[v(p(d.value.countdown)+" 秒后，返回首页",1)])),_:1})])])}}};"function"==typeof c&&c(h);var y=a(h,[["__scopeId","data-v-403579f9"]]);export{y as default};
//# sourceMappingURL=_...all_.22e926ec.js.map
