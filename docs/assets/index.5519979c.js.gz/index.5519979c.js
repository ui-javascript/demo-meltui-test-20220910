
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as e,d as a,u as s,b as i,H as n,j as t,l,T as o,O as m,t as d,h as c,e as r,g as u,k as f,f as v,L as b,P as p,n as h,J as j}from"./index.72e916e6.js";/* empty css                */import{_ as k}from"./index.72306c96.js";import _ from"./index.99733148.js";const g={key:0,class:"main-sidebar-container"},M={class:"nav"},x=["title","onClick"],y=a({name:"MainSidebar"});var w=e(Object.assign(y,{setup(e){const a=s(),y=i(),w=m("switchMenu");return(e,s)=>{const i=k,m=n;return d(),t(o,{name:"main-sidebar"},{default:l((()=>["side"===c(a).menu.menuMode||"mobile"===c(a).mode&&"single"!==c(a).menu.menuMode?(d(),r("div",g,[u(_,{"show-title":!1,class:"sidebar-logo"}),f(" 侧边栏模式（含主导航） "),v("div",M,[(d(!0),r(b,null,p(c(y).allMenus,((e,a)=>(d(),r(b,null,[e.children&&0!==e.children.length?(d(),r("div",{key:a,class:h({item:!0,active:a===c(y).actived}),title:e.meta.title,onClick:e=>c(w)(a)},[u(m,null,{default:l((()=>[e.meta.icon?(d(),t(i,{key:0,name:e.meta.icon},null,8,["name"])):f("v-if",!0)])),_:2},1024),v("span",null,j(e.meta.title),1)],10,x)):f("v-if",!0)],64)))),256))])])):f("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-0f89e93c"]]);export{w as default};
//# sourceMappingURL=index.5519979c.js.map
