
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as a,A as n,bf as s,o as e,e as t,g as o,f as l,l as r,bg as c,M as d,N as i,q as u,t as f,Y as v,J as p}from"./index.1d015b2d.js";import{E as b}from"./el-button.9b8b83db.js";import{_ as m}from"./index.6eeb5b7f.js";import"./index.8bfffa1c.js";import"./index2.538a4d30.js";import"./index2.35bfb458.js";const _=a=>(d("data-v-439c912c"),a=a(),i(),a),j={class:"notfound"},x={class:"content"},w=_((()=>l("h1",null,"404",-1))),I=_((()=>l("div",{class:"desc"},"抱歉，你访问的页面不存在",-1))),y={__name:"[...all]",setup(a){const c=u(),d=n({inter:null,countdown:5});function i(){c.push("/")}return s((()=>{clearInterval(d.value.inter)})),e((()=>{d.value.inter=setInterval((()=>{d.value.countdown--,0==d.value.countdown&&(clearInterval(d.value.inter),i())}),1e3)})),(a,n)=>{const s=m,e=b;return f(),t("div",j,[o(s,{name:"404",class:"icon"}),l("div",x,[w,I,o(e,{type:"primary",onClick:i},{default:r((()=>[v(p(d.value.countdown)+" 秒后，返回首页",1)])),_:1})])])}}};"function"==typeof c&&c(y);var g=a(y,[["__scopeId","data-v-439c912c"]]);export{g as default};
//# sourceMappingURL=_...all_.f8ab99b6.js.map
