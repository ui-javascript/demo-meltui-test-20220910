
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{R as e,U as t,d as s,y as r,c as a,t as i,e as o,n as l,h as n,C as d,k as c,i as p,E as u,I as v}from"./index.d02caf1b.js";const f=v(u(s({name:"ElDivider",props:e({direction:{type:String,values:["horizontal","vertical"],default:"horizontal"},contentPosition:{type:String,values:["left","center","right"],default:"center"},borderStyle:{type:t(String),default:"solid"}}),setup(e){const t=e,s=r("divider"),u=a((()=>s.cssVar({"border-style":t.borderStyle})));return(e,t)=>(i(),o("div",{class:l([n(s).b(),n(s).m(e.direction)]),style:p(n(u)),role:"separator"},[e.$slots.default&&"vertical"!==e.direction?(i(),o("div",{key:0,class:l([n(s).e("text"),n(s).is(e.contentPosition)])},[d(e.$slots,"default")],2)):c("v-if",!0)],6))}}),[["__file","/home/runner/work/element-plus/element-plus/packages/components/divider/src/divider.vue"]]));export{f as E};
//# sourceMappingURL=el-divider.a827a2f6.js.map
