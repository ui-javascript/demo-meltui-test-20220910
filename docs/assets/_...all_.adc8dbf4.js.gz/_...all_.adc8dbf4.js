
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as a,A as n,bf as s,o as e,e as t,g as c,f as o,l,bg as r,M as i,N as u,q as d,t as f,Y as v,J as p}from"./index.df3cea04.js";import{E as m}from"./el-button.43a81ab6.js";import{_}from"./index.df10c1fc.js";import"./index.8bfffa1c.js";import"./index2.08ccf1c8.js";import"./index2.3be8c97a.js";const b=a=>(i("data-v-439c912c"),a=a(),u(),a),j={class:"notfound"},x={class:"content"},w=b((()=>o("h1",null,"404",-1))),I=b((()=>o("div",{class:"desc"},"抱歉，你访问的页面不存在",-1))),y={__name:"[...all]",setup(a){const r=d(),i=n({inter:null,countdown:5});function u(){r.push("/")}return s((()=>{clearInterval(i.value.inter)})),e((()=>{i.value.inter=setInterval((()=>{i.value.countdown--,0==i.value.countdown&&(clearInterval(i.value.inter),u())}),1e3)})),(a,n)=>{const s=_,e=m;return f(),t("div",j,[c(s,{name:"404",class:"icon"}),o("div",x,[w,I,c(e,{type:"primary",onClick:u},{default:l((()=>[v(p(i.value.countdown)+" 秒后，返回首页",1)])),_:1})])])}}};"function"==typeof r&&r(y);var g=a(y,[["__scopeId","data-v-439c912c"]]);export{g as default};
//# sourceMappingURL=_...all_.adc8dbf4.js.map
