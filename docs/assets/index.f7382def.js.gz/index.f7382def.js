
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as e,d as a,u as s,b as n,H as i,j as t,l,T as o,O as d,t as m,h as c,e as r,g as u,f,L as b,P as p,n as v,k as h,J as j}from"./index.9528fe4a.js";/* empty css                */import{_ as k}from"./index.279f1f14.js";import _ from"./index.c29e176d.js";const g={key:0,class:"main-sidebar-container"},M={class:"nav"},x=["title","onClick"],y=a({name:"MainSidebar"});var w=e(Object.assign(y,{setup(e){const a=s(),y=n(),w=d("switchMenu");return(e,s)=>{const n=k,d=i;return m(),t(o,{name:"main-sidebar"},{default:l((()=>["side"===c(a).menu.menuMode||"mobile"===c(a).mode&&"single"!==c(a).menu.menuMode?(m(),r("div",g,[u(_,{"show-title":!1,class:"sidebar-logo"}),f("div",M,[(m(!0),r(b,null,p(c(y).allMenus,((e,a)=>(m(),r(b,null,[e.children&&0!==e.children.length?(m(),r("div",{key:a,class:v({item:!0,active:a===c(y).actived}),title:e.meta.title,onClick:e=>c(w)(a)},[u(d,null,{default:l((()=>[e.meta.icon?(m(),t(n,{key:0,name:e.meta.icon},null,8,["name"])):h("",!0)])),_:2},1024),f("span",null,j(e.meta.title),1)],10,x)):h("",!0)],64)))),256))])])):h("",!0)])),_:1})}}}),[["__scopeId","data-v-66f03716"]]);export{w as default};
