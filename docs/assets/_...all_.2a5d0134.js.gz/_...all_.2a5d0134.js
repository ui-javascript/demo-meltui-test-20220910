
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as a,A as n,bf as s,o as e,e as t,g as o,f as c,l,bg as r,M as i,N as u,q as d,t as f,Y as v,J as p}from"./index.204d60c9.js";import{E as m}from"./el-button.b43c86ba.js";import{_ as b}from"./index.de035b61.js";import"./index.8bfffa1c.js";import"./index2.907e84fb.js";import"./index2.35335773.js";const _=a=>(i("data-v-439c912c"),a=a(),u(),a),j={class:"notfound"},x={class:"content"},w=_((()=>c("h1",null,"404",-1))),I=_((()=>c("div",{class:"desc"},"抱歉，你访问的页面不存在",-1))),y={__name:"[...all]",setup(a){const r=d(),i=n({inter:null,countdown:5});function u(){r.push("/")}return s((()=>{clearInterval(i.value.inter)})),e((()=>{i.value.inter=setInterval((()=>{i.value.countdown--,0==i.value.countdown&&(clearInterval(i.value.inter),u())}),1e3)})),(a,n)=>{const s=b,e=m;return f(),t("div",j,[o(s,{name:"404",class:"icon"}),c("div",x,[w,I,o(e,{type:"primary",onClick:u},{default:l((()=>[v(p(i.value.countdown)+" 秒后，返回首页",1)])),_:1})])])}}};"function"==typeof r&&r(y);var g=a(y,[["__scopeId","data-v-439c912c"]]);export{g as default};
//# sourceMappingURL=_...all_.2a5d0134.js.map
