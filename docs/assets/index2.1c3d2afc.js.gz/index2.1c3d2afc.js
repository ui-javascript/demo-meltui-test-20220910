
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{u as e}from"./index2.c2e41879.js";import{O as a,bd as d,b9 as n,A as o,c as t,o as l,w as u,aD as s,X as i}from"./index.c66562dd.js";const v=()=>({form:a(d,void 0),formItem:a(n,void 0)}),r=(a,{formItemContext:d,disableIdGeneration:n,disableIdManagement:v})=>{n||(n=o(!1)),v||(v=o(!1));const r=o();let m;const I=t((()=>{var e;return!!(!a.label&&d&&d.inputIds&&(null==(e=d.inputIds)?void 0:e.length)<=1)}));return l((()=>{m=u([s(a,"id"),n],(([a,n])=>{const o=null!=a?a:n?void 0:e().value;o!==r.value&&((null==d?void 0:d.removeInputId)&&(r.value&&d.removeInputId(r.value),(null==v?void 0:v.value)||n||!o||d.addInputId(o)),r.value=o)}),{immediate:!0})})),i((()=>{m&&m(),(null==d?void 0:d.removeInputId)&&r.value&&d.removeInputId(r.value)})),{isLabeledByFormItem:I,inputId:r}};export{r as a,v as u};
//# sourceMappingURL=index2.1c3d2afc.js.map
