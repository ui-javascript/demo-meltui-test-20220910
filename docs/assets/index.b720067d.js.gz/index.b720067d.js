
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as e,d as a,u as s,b as i,H as n,j as t,l as r,T as d,O as o,t as c,h as m,e as l,f,g as p,k as u,L as j,P as v,n as x,J as b}from"./index.df3cea04.js";/* empty css                */import{_ as h}from"./index.df10c1fc.js";import k from"./index.1ea1f869.js";import _ from"./index.9cfb2010.js";import"./el-button.43a81ab6.js";import"./index.8bfffa1c.js";import"./index2.08ccf1c8.js";import"./index2.3be8c97a.js";/* empty css                  */import"./index2.4a41f32a.js";import"./error2.13f96d52.js";import"./index2.07a9adfe.js";const y={key:0},g={class:"header-container"},M={class:"main"},C={class:"nav"},H=["onClick"],O={key:0},w=a({name:"Header"});var I=e(Object.assign(w,{setup(e){const a=s(),w=i(),I=o("switchMenu");return(e,s)=>{const i=h,o=n;return c(),t(d,{name:"header"},{default:r((()=>["pc"===m(a).mode&&"head"===m(a).menu.menuMode?(c(),l("header",y,[f("div",g,[f("div",M,[p(k),u(" 顶部模式 "),f("div",C,[(c(!0),l(j,null,v(m(w).allMenus,((e,a)=>(c(),l(j,null,[e.children&&0!==e.children.length?(c(),l("div",{key:a,class:x(["item",{active:a==m(w).actived}]),onClick:e=>m(I)(a)},[p(o,null,{default:r((()=>[e.meta.icon?(c(),t(i,{key:0,name:e.meta.icon},null,8,["name"])):u("v-if",!0)])),_:2},1024),e.meta.title?(c(),l("span",O,b(e.meta.title),1)):u("v-if",!0)],10,H)):u("v-if",!0)],64)))),256))])]),p(_)])])):u("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-339849a1"]]);export{I as default};
//# sourceMappingURL=index.b720067d.js.map
