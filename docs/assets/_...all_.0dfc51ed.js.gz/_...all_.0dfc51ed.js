
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as a,A as n,bB as s,o as e,e as t,g as o,f as l,l as r,bh as c,M as i,N as u,q as d,t as f,Y as v,J as p}from"./index.054a5a2f.js";import{E as m}from"./el-button.e0d309e3.js";import{_}from"./index.f52660da.js";import"./index.8bfffa1c.js";import"./index2.8a7a14f9.js";import"./index2.69cb89c7.js";const j=a=>(i("data-v-403579f9"),a=a(),u(),a),x={class:"notfound"},b={class:"content"},w=j((()=>l("h1",null,"404",-1))),I=j((()=>l("div",{class:"desc"},"抱歉，你访问的页面不存在",-1))),h={__name:"[...all]",setup(a){const c=d(),i=n({inter:null,countdown:5});function u(){c.push("/")}return s((()=>{clearInterval(i.value.inter)})),e((()=>{i.value.inter=setInterval((()=>{i.value.countdown--,0==i.value.countdown&&(clearInterval(i.value.inter),u())}),1e3)})),(a,n)=>{const s=_,e=m;return f(),t("div",x,[o(s,{name:"404",class:"icon"}),l("div",b,[w,I,o(e,{type:"primary",onClick:u},{default:r((()=>[v(p(i.value.countdown)+" 秒后，返回首页",1)])),_:1})])])}}};"function"==typeof c&&c(h);var y=a(h,[["__scopeId","data-v-403579f9"]]);export{y as default};
//# sourceMappingURL=_...all_.0dfc51ed.js.map
