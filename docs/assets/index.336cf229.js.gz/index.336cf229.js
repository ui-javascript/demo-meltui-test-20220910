
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as a,d as e,u as s,b as i,H as n,j as t,l,T as d,O as o,t as m,h as c,e as r,g as u,k as f,f as v,L as b,P as p,n as h,J as j}from"./index.db65a036.js";/* empty css                */import{_ as k}from"./index.1c3aad5d.js";import _ from"./index.b609ec7a.js";const g={key:0,class:"main-sidebar-container"},M={class:"nav"},x=["title","onClick"],y=e({name:"MainSidebar"});var w=a(Object.assign(y,{setup(a){const e=s(),y=i(),w=o("switchMenu");return(a,s)=>{const i=k,o=n;return m(),t(d,{name:"main-sidebar"},{default:l((()=>["side"===c(e).menu.menuMode||"mobile"===c(e).mode&&"single"!==c(e).menu.menuMode?(m(),r("div",g,[u(_,{"show-title":!1,class:"sidebar-logo"}),f(" 侧边栏模式（含主导航） "),v("div",M,[(m(!0),r(b,null,p(c(y).allMenus,((a,e)=>(m(),r(b,null,[a.children&&0!==a.children.length?(m(),r("div",{key:e,class:h({item:!0,active:e===c(y).actived}),title:a.meta.title,onClick:a=>c(w)(e)},[u(o,null,{default:l((()=>[a.meta.icon?(m(),t(i,{key:0,name:a.meta.icon},null,8,["name"])):f("v-if",!0)])),_:2},1024),v("span",null,j(a.meta.title),1)],10,x)):f("v-if",!0)],64)))),256))])])):f("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-66f03716"]]);export{w as default};
//# sourceMappingURL=index.336cf229.js.map
