
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as a,_ as e,aV as s,A as t,t as l,e as i,C as o,L as n,Y as d,J as c,k as p,g as r,l as u,n as v,i as f,H as g}from"./index.c66562dd.js";/* empty css                */import{_ as m}from"./index.46d30d13.js";const y={key:0,class:"title-container"},h=a({name:"PageMain"});var k=e(Object.assign(h,{props:{title:{type:String,default:""},collaspe:{type:Boolean,default:!1},height:{type:String,default:""}},setup(a){const e=a,h=!!s().title,k=t(e.collaspe);function _(){k.value=!1}return(e,s)=>{const t=m,j=g;return l(),i("div",{class:v({"page-main":!0,"is-collaspe":k.value}),style:f({height:k.value?a.height:""})},[h||a.title?(l(),i("div",y,[h?o(e.$slots,"title",{key:0},void 0,!0):(l(),i(n,{key:1},[d(c(a.title),1)],64))])):p("v-if",!0),o(e.$slots,"default",{},void 0,!0),k.value?(l(),i("div",{key:1,class:"collaspe",title:"展开",onClick:_},[r(j,null,{default:u((()=>[r(t,{name:"ep:arrow-down"})])),_:1})])):p("v-if",!0)],6)}}}),[["__scopeId","data-v-0c1f52aa"]]);export{k as _};
//# sourceMappingURL=index.161b7020.js.map
