
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as e,d as s,u as a,b as o,A as n,h as l,e as t,g as i,n as u,l as d,k as p,t as r,Q as m,L as c,P as b,j as f}from"./index.9528fe4a.js";import"./el-tooltip.0ca4bad9.js";/* empty css                  */import j from"./index.c29e176d.js";import{E as g,S as h}from"./index.6b694ed0.js";/* empty css                */import"./index.279f1f14.js";import"./index2.6bd4f6d7.js";import"./error2.13f96d52.js";import"./index2.709687ee.js";import"./index.8bfffa1c.js";import"./typescript2.b7eef2c1.js";const M=s({name:"SubSidebar"});var v=e(Object.assign(M,{setup(e){const s=a(),M=o(),v=n(0);function x(e){v.value=e.target.scrollTop}return(e,a)=>{const o=g;return["side","head","single"].includes(l(s).menu.menuMode)||"mobile"===l(s).mode?(r(),t("div",{key:0,class:u(["sub-sidebar-container",{"is-collapse":"pc"===l(s).mode&&l(s).menu.subMenuCollapse}]),onScroll:x},[i(j,{"show-logo":"single"===l(s).menu.menuMode,class:u({"sidebar-logo":!0,"sidebar-logo-bg":"single"===l(s).menu.menuMode,shadow:v.value})},null,8,["show-logo","class"]),i(o,{"unique-opened":l(s).menu.subMenuUniqueOpened,"default-openeds":l(M).defaultOpenedPaths,"default-active":e.$route.meta.activeMenu||e.$route.path,collapse:"pc"===l(s).mode&&l(s).menu.subMenuCollapse,"collapse-transition":!1,class:u({"is-collapse-without-logo":"single"!==l(s).menu.menuMode&&l(s).menu.subMenuCollapse})},{default:d((()=>[i(m,{name:"sub-sidebar"},{default:d((()=>[(r(!0),t(c,null,b(l(M).sidebarMenus,((e,s)=>(r(),t(c,null,[!1!==e.meta.sidebar?(r(),f(h,{key:e.path||s,item:e,"base-path":e.path},null,8,["item","base-path"])):p("",!0)],64)))),256))])),_:1})])),_:1},8,["unique-opened","default-openeds","default-active","collapse","class"])],34)):p("",!0)}}}),[["__scopeId","data-v-e6fe94ea"]]);export{v as default};
