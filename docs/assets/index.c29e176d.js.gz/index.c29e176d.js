
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as a,d as s,u as e,A as o,c as t,j as l,l as n,h as r,n as d,s as u,t as i,e as c,k as p,J as b}from"./index.9528fe4a.js";const g=["src"],h={key:1},f=s({name:"Logo"});var m=a(Object.assign(f,{props:{showLogo:{type:Boolean,default:!0},showTitle:{type:Boolean,default:!0}},setup(a){const s=e(),f=o("admin后台"),m=o("./assets/logo.eb12b828.png"),k=t((()=>{let a={};return s.dashboard.enable&&(a.name="dashboard"),a}));return(e,o)=>{const t=u("router-link");return i(),l(t,{to:r(k),class:d(["title",{"is-link":r(s).dashboard.enable}]),title:f.value},{default:n((()=>[a.showLogo?(i(),c("img",{key:0,src:m.value,class:"logo"},null,8,g)):p("",!0),a.showTitle?(i(),c("span",h,b(f.value),1)):p("",!0)])),_:1},8,["to","class","title"])}}}),[["__scopeId","data-v-fc6b657e"]]);export{m as default};
