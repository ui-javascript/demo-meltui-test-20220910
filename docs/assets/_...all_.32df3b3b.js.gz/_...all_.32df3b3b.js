
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as a,A as e,bf as n,o as s,e as t,g as o,f as c,l,bg as r,M as i,N as d,q as u,t as f,Y as v,J as p}from"./index.eae74150.js";import{E as m}from"./el-button.8ec224ee.js";import{_}from"./index.72474cf8.js";import"./index.8bfffa1c.js";import"./index2.fa08d5ee.js";import"./index2.4baed5bd.js";const b=a=>(i("data-v-439c912c"),a=a(),d(),a),j={class:"notfound"},x={class:"content"},w=b((()=>c("h1",null,"404",-1))),I=b((()=>c("div",{class:"desc"},"抱歉，你访问的页面不存在",-1))),y={__name:"[...all]",setup(a){const r=u(),i=e({inter:null,countdown:5});function d(){r.push("/")}return n((()=>{clearInterval(i.value.inter)})),s((()=>{i.value.inter=setInterval((()=>{i.value.countdown--,0==i.value.countdown&&(clearInterval(i.value.inter),d())}),1e3)})),(a,e)=>{const n=_,s=m;return f(),t("div",j,[o(n,{name:"404",class:"icon"}),c("div",x,[w,I,o(s,{type:"primary",onClick:d},{default:l((()=>[v(p(i.value.countdown)+" 秒后，返回首页",1)])),_:1})])])}}};"function"==typeof r&&r(y);var g=a(y,[["__scopeId","data-v-439c912c"]]);export{g as default};
//# sourceMappingURL=_...all_.32df3b3b.js.map
