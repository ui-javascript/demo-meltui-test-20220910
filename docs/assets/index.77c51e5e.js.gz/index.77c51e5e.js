
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as e,d as a,u as s,b as i,H as n,j as t,l as d,T as r,O as o,t as m,h as c,e as l,f as p,g as f,k as u,L as j,P as v,n as b,J as x}from"./index.77a2b8a5.js";/* empty css                */import{_ as h}from"./index.dcd4b65f.js";import k from"./index.52cb0898.js";import _ from"./index.56c2b8c1.js";import"./el-button.5a3907a7.js";import"./index.8bfffa1c.js";import"./index2.240ee0c6.js";import"./index2.1dc5c761.js";/* empty css                  */import"./index2.b138d437.js";import"./error2.13f96d52.js";import"./index2.a5df202e.js";const y={key:0},g={class:"header-container"},M={class:"main"},C={class:"nav"},H=["onClick"],O={key:0},w=a({name:"Header"});var I=e(Object.assign(w,{setup(e){const a=s(),w=i(),I=o("switchMenu");return(e,s)=>{const i=h,o=n;return m(),t(r,{name:"header"},{default:d((()=>["pc"===c(a).mode&&"head"===c(a).menu.menuMode?(m(),l("header",y,[p("div",g,[p("div",M,[f(k),u(" 顶部模式 "),p("div",C,[(m(!0),l(j,null,v(c(w).allMenus,((e,a)=>(m(),l(j,null,[e.children&&0!==e.children.length?(m(),l("div",{key:a,class:b(["item",{active:a==c(w).actived}]),onClick:e=>c(I)(a)},[f(o,null,{default:d((()=>[e.meta.icon?(m(),t(i,{key:0,name:e.meta.icon},null,8,["name"])):u("v-if",!0)])),_:2},1024),e.meta.title?(m(),l("span",O,x(e.meta.title),1)):u("v-if",!0)],10,H)):u("v-if",!0)],64)))),256))])]),f(_)])])):u("v-if",!0)])),_:1})}}}),[["__scopeId","data-v-339849a1"]]);export{I as default};
//# sourceMappingURL=index.77c51e5e.js.map
