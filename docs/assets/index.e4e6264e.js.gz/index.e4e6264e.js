
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as e,d as s,u as a,b as o,A as n,h as l,e as t,g as i,n as u,k as d,l as p,t as r,Q as m,L as c,P as b,j as f}from"./index.204d60c9.js";import"./el-tooltip.0ca4bad9.js";/* empty css                  */import j from"./index.628407c1.js";import{E as g,S as h}from"./index.47fee9d6.js";/* empty css                */import"./index.de035b61.js";import"./index2.812f0b64.js";import"./error2.13f96d52.js";import"./index2.35335773.js";import"./index.8bfffa1c.js";import"./typescript2.b7eef2c1.js";const v=s({name:"SubSidebar"});var M=e(Object.assign(v,{setup(e){const s=a(),v=o(),M=n(0);function x(e){M.value=e.target.scrollTop}return(e,a)=>{const o=g;return["side","head","single"].includes(l(s).menu.menuMode)||"mobile"===l(s).mode?(r(),t("div",{key:0,class:u(["sub-sidebar-container",{"is-collapse":"pc"===l(s).mode&&l(s).menu.subMenuCollapse}]),onScroll:x},[i(j,{"show-logo":"single"===l(s).menu.menuMode,class:u({"sidebar-logo":!0,"sidebar-logo-bg":"single"===l(s).menu.menuMode,shadow:M.value})},null,8,["show-logo","class"]),d(" 侧边栏模式（无主导航） "),i(o,{"unique-opened":l(s).menu.subMenuUniqueOpened,"default-openeds":l(v).defaultOpenedPaths,"default-active":e.$route.meta.activeMenu||e.$route.path,collapse:"pc"===l(s).mode&&l(s).menu.subMenuCollapse,"collapse-transition":!1,class:u({"is-collapse-without-logo":"single"!==l(s).menu.menuMode&&l(s).menu.subMenuCollapse})},{default:p((()=>[i(m,{name:"sub-sidebar"},{default:p((()=>[(r(!0),t(c,null,b(l(v).sidebarMenus,((e,s)=>(r(),t(c,null,[!1!==e.meta.sidebar?(r(),f(h,{key:e.path||s,item:e,"base-path":e.path},null,8,["item","base-path"])):d("v-if",!0)],64)))),256))])),_:1})])),_:1},8,["unique-opened","default-openeds","default-active","collapse","class"])],34)):d("v-if",!0)}}}),[["__scopeId","data-v-e6fe94ea"]]);export{M as default};
//# sourceMappingURL=index.e4e6264e.js.map
