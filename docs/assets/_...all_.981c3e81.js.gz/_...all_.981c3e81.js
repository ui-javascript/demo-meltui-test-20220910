
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as a,A as n,bf as s,o as t,e,g as o,f as c,l,bg as r,M as d,N as i,q as u,t as f,Y as v,J as p}from"./index.db9cd41d.js";import{E as m}from"./el-button.96f93a4b.js";import{_}from"./index.8dca6185.js";import"./index.8bfffa1c.js";import"./index2.114c7283.js";import"./index2.7e034c23.js";const b=a=>(d("data-v-439c912c"),a=a(),i(),a),j={class:"notfound"},x={class:"content"},w=b((()=>c("h1",null,"404",-1))),I=b((()=>c("div",{class:"desc"},"抱歉，你访问的页面不存在",-1))),y={__name:"[...all]",setup(a){const r=u(),d=n({inter:null,countdown:5});function i(){r.push("/")}return s((()=>{clearInterval(d.value.inter)})),t((()=>{d.value.inter=setInterval((()=>{d.value.countdown--,0==d.value.countdown&&(clearInterval(d.value.inter),i())}),1e3)})),(a,n)=>{const s=_,t=m;return f(),e("div",j,[o(s,{name:"404",class:"icon"}),c("div",x,[w,I,o(t,{type:"primary",onClick:i},{default:l((()=>[v(p(d.value.countdown)+" 秒后，返回首页",1)])),_:1})])])}}};"function"==typeof r&&r(y);var g=a(y,[["__scopeId","data-v-439c912c"]]);export{g as default};
//# sourceMappingURL=_...all_.981c3e81.js.map
