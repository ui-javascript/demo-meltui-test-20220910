
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{d as e,_ as a,aV as s,A as t,t as l,e as i,C as o,L as n,Y as c,J as d,k as p,g as r,l as u,n as v,i as f,H as g}from"./index.e55c74a9.js";/* empty css                */import{_ as m}from"./index.7ea0c27e.js";const y={key:0,class:"title-container"},h=e({name:"PageMain"});var k=a(Object.assign(h,{props:{title:{type:String,default:""},collaspe:{type:Boolean,default:!1},height:{type:String,default:""}},setup(e){const a=e,h=!!s().title,k=t(a.collaspe);function _(){k.value=!1}return(a,s)=>{const t=m,j=g;return l(),i("div",{class:v({"page-main":!0,"is-collaspe":k.value}),style:f({height:k.value?e.height:""})},[h||e.title?(l(),i("div",y,[h?o(a.$slots,"title",{key:0},void 0,!0):(l(),i(n,{key:1},[c(d(e.title),1)],64))])):p("v-if",!0),o(a.$slots,"default",{},void 0,!0),k.value?(l(),i("div",{key:1,class:"collaspe",title:"展开",onClick:_},[r(j,null,{default:u((()=>[r(t,{name:"ep:arrow-down"})])),_:1})])):p("v-if",!0)],6)}}}),[["__scopeId","data-v-41484d56"]]);export{k as _};
//# sourceMappingURL=index.1185a0d4.js.map
