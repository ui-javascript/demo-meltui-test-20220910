
/**
 * 由 Fantastic-admin 提供技术支持
 * Powered by Fantastic-admin
 * https://fantastic-admin.netlify.app
 * 代码仓库
 * Gitee  https://gitee.com/hooray/fantastic-admin
 * Github https://github.com/hooray/fantastic-admin
 */
    
import{_ as s,d as a,u as e,A as o,c as t,j as l,l as n,h as r,n as d,s as i,t as u,e as c,k as p,J as b}from"./index.204d60c9.js";const f=["src"],g={key:1},h=a({name:"Logo"});var v=s(Object.assign(h,{props:{showLogo:{type:Boolean,default:!0},showTitle:{type:Boolean,default:!0}},setup(s){const a=e(),h=o("admin后台"),v=o("./assets/logo.eb12b828.png"),m=t((()=>{let s={};return a.dashboard.enable&&(s.name="dashboard"),s}));return(e,o)=>{const t=i("router-link");return u(),l(t,{to:r(m),class:d(["title",{"is-link":r(a).dashboard.enable}]),title:h.value},{default:n((()=>[s.showLogo?(u(),c("img",{key:0,src:v.value,class:"logo"},null,8,f)):p("v-if",!0),s.showTitle?(u(),c("span",g,b(h.value),1)):p("v-if",!0)])),_:1},8,["to","class","title"])}}}),[["__scopeId","data-v-fc6b657e"]]);export{v as default};
//# sourceMappingURL=index.628407c1.js.map
